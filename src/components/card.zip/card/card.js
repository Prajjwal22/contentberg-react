import React from 'react'
import Photo from '../../assets/profile.jpg'
function Card() {
  return (
    <div className='card'>
        <h3>Cruising and Crushing</h3>
        <div className="cardImg">
        <img src={Photo}  alt="Logo" />
        </div>
        <div className='cardDesc'>
          <p>The title is given to an employee for consistently improving on their performance every month and showing the best results.</p>
        </div>

    </div>
  )
}

export default Card